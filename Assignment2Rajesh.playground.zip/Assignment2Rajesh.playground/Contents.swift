import UIKit
//Write a class named Student which will have student records
//Properties
//First name
//Last name
//Mobile number
//Email (Email would be unique)
//Roll number (Roll number would be unique)
//- Take array of dictionary to store data
//Write a function to add students
//Write a function to get all students
//Write a function to get an information of a particular student based on his roll number
print("__________________________________________________________________")
class Student{
    var firstName: String?
    var lastName: String?
    var mobileNo: Int?
    var email: String?
    var rollNo: Int?
    var studentInfo = [String: Any]()
    var students = [[String: Any]]()
    func addStudent(){
        if let firstNameVar = firstName { studentInfo["firstName"] = firstNameVar }
        if let lastNameVar = lastName { studentInfo["lastName"] = lastNameVar }
        if let mobileNoVar = mobileNo { studentInfo["mobileNo"] = mobileNoVar }
        if let emailVar = email { studentInfo["email"] = emailVar }
        if let rollNoVar = rollNo { studentInfo["rollNo"] = rollNoVar }
        students.append(studentInfo)
    }
    func getStudents(){
        print(students as Any)
    }
    func getStudentAt(rollNumber: Int){
        for rollNum in 0..<students.count {
            if students[rollNum]["rollNo"] as! Int == rollNumber{
                print(students[rollNum])
                return
            }
        }
        print("Not Present")
    }
}
var student = Student()
student.firstName = "Rajesh"
student.lastName = "Bohra"
student.mobileNo = 1234567890
student.email = "r@app.com"
student.rollNo = 21
student.addStudent()
student.firstName = "Rishabh"
student.lastName = "Gupta"
student.mobileNo = 0987654321
student.email = "ri@app.com"
student.rollNo = 22
student.addStudent()
student.getStudents()
student.getStudentAt(rollNumber: 22)
print("__________________________________________________________________")

//Write an example of following in Swift
//Encapsulation
class StudentInfo {
    private var name = " "
    private var rollNo = 0
    private var age = 0
    func getAge()->Int { return age }
    func getName()->String { return name }
    func getRollNo()->Int { return rollNo }
    func setAge(newAge: Int) { age = newAge }
    func setName(newName: String){  name = newName }
    func setRollNo(newRollNo: Int){ rollNo = newRollNo }
}
let studentInfo = StudentInfo()
studentInfo.setName(newName: "Rajesh Singh Bohra")
studentInfo.setAge(newAge: 21)
studentInfo.setRollNo(newRollNo: 1729010128)
print("Student Name: \(studentInfo.getName())")
print("Student Age:  \(studentInfo.getAge())")
print("Student Roll Number : \(studentInfo.getRollNo())")
print("__________________________________________________________________")
//Abstraction
protocol ShapeProtocol{
    func area()->Double
    func toString()->String
    func getColor()->String
}
class CircleDummy: ShapeProtocol{
    var radius: Double = 0.0
    var color: String = " "
    init(color: String, radius: Double){
        self.color = color
        self.radius = radius
    }
    func area()-> Double{
        return  Double((22/7)*radius*radius)
    }
    func toString()-> String{
        return "area of circle is: \(area()) and \(getColor())"
    }
    func getColor() -> String {
        return "color of circle is: \(color)"
    }
}
class RectangleDummys: CircleDummy {
    var length: Double
    var width: Double
    init(color: String, length: Double, width: Double){
        self.length = length
        self.width = width
        super.init(color: color, radius: 0)
    }
    override func area()->Double { return Double(length*width) }
    override func toString()->String {
        return "area of rectangle is: \(area())  and color of rectangle is: \(getColor())"
    }
}
let s1 = CircleDummy(color: "Red",radius: 2.2)
let s2 = RectangleDummys(color: "Yellow",length: 2,width: 4)
print(s1.toString())
print(s2.toString())
print("__________________________________________________________________")
//Polymorphism
class MultiplyClass {
    // Method with 2 integer parameter
    static func Multiply(a: Int, b: Int)->Int{
        return a*b
    }
    // Method with the same name but 2 double parameter
    static func Multiply(a: Double, b: Double)->Double{
        return a*b
    }
}
print("Multiply with integers: \(MultiplyClass.Multiply(a: 3, b: 4))")
print("Multiply with doubles: \(MultiplyClass.Multiply(a: 3.3, b: 4.4))")
print("__________________________________________________________________")
//Inheritance
// base class
class Bicycle {
    var gear = 0
    var speed = 0
    init(gear: Int, speed: Int){
        self.gear = gear
        self.speed = speed
    }
    func applyBrake(decrement: Int){
        speed = speed - decrement
    }
    func speedUp(increment: Int){
        speed = speed + increment
    }
    // toString() method to print info of Bicycle
    func toString()->String{
        return ("Number of gears are: \(gear)       Speed of bicycle is: \(speed)");
    }
}
// derived class
class MountainBike: Bicycle{
    var seatHeight = 0
    init(gear: Int, speed: Int, startHeight: Int){
        super.init(gear: gear, speed: speed)
        seatHeight = startHeight
    }
    func setHeight(newValue: Int){
        seatHeight = newValue
    }
    override func toString()->String{
        return ("\(super.toString())        Seat height is: \(seatHeight)")
    }
}
let mountainBike = MountainBike(gear: 3, speed: 100, startHeight: 25)
print(mountainBike.toString())
print("__________________________________________________________________")

//Create a class of Coordinate
//Write a function to add coordinates
//Write a function to get the coordinates
//Write a function to calculate distance between two coordinates
class Coordinate{
    var x1: Int?
    var y1: Int?
    var x2: Int?
    var y2: Int?
    var x: Int?
    var y: Int?
    init(x1: Int , y1: Int , x2: Int , y2: Int){
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2
    }
    func addCoordinates(){
        if let x1Var = x1, let x2Var = x2 { x = x1Var+x2Var }
        if let y1Var = y1, let y2Var = y2 { y = y1Var+y2Var }
    }
    func getCoordinates(){
        if let xVar = x, let yVar = y { print("x coordinate :- \(xVar)     y coordinate :- \(yVar)") }
    }
    func calcDistance(){
        if let x1Var = x1, let x2Var = x2, let y1Var = y1, let y2Var = y2 {
            print("Distance between points is :- \(sqrt(Double((x2Var-x1Var*(x2Var-x1Var) + (y2Var-y1Var)*(y2Var-y1Var)))))")
        }
    }
}
let coordinate = Coordinate(x1: 1, y1: 2, x2: 3, y2: 4)
coordinate.addCoordinates()
coordinate.getCoordinates()
coordinate.calcDistance()
print("__________________________________________________________________")

//Create a structure and write following methods
//To calculate factorial of a number
//Sort an array in descending order
//To find second largest number in an array
struct General{
    //factorial
    func factorial(fact: Int){
        if(fact < 0){
            print("Negative number")
        }
        if(fact == 0 || fact == 1) { print("factorial of \(fact) is :- 1")
        }
        var result: Int = 1
        for i in 1...fact{ result = result * i }
        print("factorial of \(fact) is :- \(result)")
    }
    //sorting array in descending order
    func descendingSort(size: Int ,array: [Int])-> [Int] {
        var dummy = array
        for i in 0..<size{
            for j in (i+1)..<size{
                if dummy[i] < dummy[j]{
                    let temp = dummy[i]
                    dummy[i] = dummy[j]
                    dummy[j] = temp
                }
            }
        }
        return dummy
    }
    //find second largest number in array
    func secondMax(size: Int ,array: [Int]) {
        let dummy = array
        let reversed = descendingSort(size: dummy.count, array: dummy)
        print("Second maximum number in \(array) is :- \(reversed[1])")
    }
}
let general = General()
general.factorial(fact: 6)
print("Descending order of array is: \(general.descendingSort(size: 6, array: [1, 2, 3, 4, 5, 6]))")
general.secondMax(size: 6, array: [1, 2, 3, 4, 5, 6])
print("__________________________________________________________________")

//Calculate area of a Circle, Rectangle and a Triangle.
//Create a protocol with two methods with following names
//input
//area
//Create a class of Circle
//Implement protocol methods
//Declare required properties to calculate area of a circle
//Assign values of properties (Hard code)
//Area method will calculate the area of circle and print it
//Create a class of Rectangle
//Inherit Circle class
//Implement protocol methods
//Declare required properties to calculate area of a Rectangle
//Assign values of properties (Hard code)
//Area method will calculate the area of Rectangle and print it
//Create a class of Triangle
//Inherit Rectangle
//Implement protocol methods
//Declare required properties to calculate area of a Rectangle
//Assign values of properties (Hard code)
//Area method will calculate the area of Triangle and print it
//Create an object of Triangle class
//Display area of Circle, Rectangle and Triangle.
//Important Instructions
//Use Swift language
//Use concepts of Abstraction and Inheritance
//Create this program in a playground
//After calculating the area of all three with hardcoded values, do the same assessment with dynamic values in a separate playground.
protocol  GeneralProtocol{
    func input()
    func area(firstInput: Int, secondInput: Int)->Double
}
class Circle: GeneralProtocol{
    var radius: Int?
    init(radius: Int) {
        self.radius = radius
    }
    func input() {
        if let radiusVar = radius { print( "Area of circle with radius \(radiusVar) is :- \(Double(area(firstInput: radiusVar, secondInput: 0)))") }
    }
    func area(firstInput: Int, secondInput: Int)-> Double {
        return Double((22/7)*firstInput*firstInput)
    }
}
let circle = Circle(radius: 7)
circle.input()
class RectangleDummy: GeneralProtocol{
    var length: Int?
    var breadth: Int?
    init(length: Int, breadth: Int) {
        self.length = length
        self.breadth = breadth
    }
    func input(){
        if let lengthVar = length, let breadthVar = breadth { print("Area of rectangle with length \(lengthVar) & breadth \(breadthVar) is :- \(area(firstInput: lengthVar, secondInput: breadthVar))") }
    }
    func area(firstInput: Int, secondInput: Int)->Double {
        return Double(firstInput*secondInput)
    }
}
let reactangle = RectangleDummy(length: 5, breadth: 10)
reactangle.input()
class Triangle: GeneralProtocol{
    var base: Int?
    var height: Int?
    init(base: Int, height: Int) {
        self.base = base
        self.height = height
    }
    func input(){
        if let baseVar = base, let heightvar = height {  print("Area of triangle with base \(baseVar) & height \(heightvar) is :- \(area(firstInput: 13, secondInput: 6))") }
    }
    func area(firstInput: Int, secondInput: Int)-> Double {
        return Double(firstInput*secondInput/2)
    }
}
let triangle = Triangle(base: 13, height: 6)
triangle.input()
print("__________________________________________________________________")

//Q6: Create a Calculator
//
//Create a protocol with 4 methods
//Add
//Subtract
//Multiply
//Division
//Create a class Calculator and implement all the protocol methods
//Write mechanism to use Calculator’s behaviour
protocol  CalculatorProtocol{
    func addCalc()
    func subCalc()
    func mulCalc()
    func divCalc()
}
class Calculator: CalculatorProtocol {
    var firstNum: Int?
    var secondNum: Int?
    init(firstNum: Int, secondNum: Int) {
        self.firstNum = firstNum
        self.secondNum = secondNum
    }
    func addCalc() {
        if let firstNumVar = firstNum, let secondNumVar = secondNum { print("Addtion of \(firstNumVar) & \(secondNumVar) is :- \(firstNumVar + secondNumVar)") }
    }
    func subCalc() {
        if let firstNumVar = firstNum, let secondNumVar = secondNum { print("Subtraction of \(firstNumVar) & \(secondNumVar) is :- \(firstNumVar - secondNumVar)") }
    }
    func mulCalc() {
        if let firstNumVar = firstNum, let secondNumVar = secondNum { print("Multiply of \(firstNumVar) & \(secondNumVar) is :- \(firstNumVar*secondNumVar)") }
    }
    func divCalc() {
        if let firstNumVar = firstNum, let secondNumVar = secondNum { print("Division of \(firstNumVar) & \(secondNumVar) is :- \(firstNumVar/secondNumVar)") }
    }
    let squareRootClosure: (Double) -> Double = { (num) in
        return(sqrt(Double(num)))
    }
}
let calculate = Calculator(firstNum: 12, secondNum: 2)
calculate.addCalc()
calculate.addCalc()
calculate.subCalc()
calculate.mulCalc()
calculate.divCalc()
print("Square root of given number: \(calculate.squareRoot(input: 100.0))")
print("__________________________________________________________________")

//Q7: Write a function to find min and max number from an array and send completion callback through a closure
let minMaxArray: ([Int]) -> (Int,Int) = { array in
    var dummy = array
    for i in 0..<dummy.count{
        for j in (i+1)..<dummy.count{
            if dummy[i] < dummy[j]{
                let temp = dummy[i]
                dummy[i] = dummy[j]
                dummy[j] = temp
            }
        }
    }
    let maxInArray = dummy[0]
    let minInArray = dummy[dummy.count-1]
    return (minInArray, maxInArray)
}
let minMaxResult = minMaxArray([1, 2, 3, 4, 5, 6])
print("Minimum : \(minMaxResult.0)      Maximum : \(minMaxResult.1)")
print("__________________________________________________________________")

//Q8: Add a new feature in Calculator class to calculate square root of a number and send it through a closure
//Use extension to add functionality in existing class
extension Calculator{
    func squareRoot(input: Double)-> Double{ return Double(squareRootClosure(input)) }
}
